# Hacker Dream UI Theme

[![CircleCI](https://img.shields.io/badge/build-passing-brightgreen.svg)]()
[![CircleCI](https://img.shields.io/badge/version-1.0.0b-blue.svg)]()

A simple but helpful, dark but full of 'three :)' colors theme.<br>
For a complete experience as demonstrated in the screenshot below,<br>
use the [Hacker Dream syntax theme](https://atom.io/themes/hacker-dream-syntax).

[My Github account](https://www.github.com/xeroxyde)<br>
[Follow me on Twitter](https://www.twitter.com/xeroxyde)<br>

If you want to submit something to include into the theme, do not hesitate to suggest me or to fork it and do it yourself.
![Sample](https://raw.githubusercontent.com/xeroxyde/hacker-dream-ui/master/sample.png)
