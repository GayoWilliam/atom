## 1.0.0b - First Release
* Just created the theme on the fly.

## 1.1.0b
* Harmonize colors throughout all the theme
* Fix graphic bug that causes selected tree view items to be invisible
* Change selected item text color to white
* Change selected item background color to red
* Remove deprecated pseudo-selectors
